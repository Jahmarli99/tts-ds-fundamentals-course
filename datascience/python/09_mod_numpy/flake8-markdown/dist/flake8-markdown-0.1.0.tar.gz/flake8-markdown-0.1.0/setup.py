# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['flake8_markdown']

package_data = \
{'': ['*']}

install_requires = \
['flake8>=3.7,<4.0']

setup_kwargs = {
    'name': 'flake8-markdown',
    'version': '0.1.0',
    'description': 'Flake 8 is my first package I ever created for Python Developers',
    'long_description': None,
    'author': 'GS Jackson',
    'author_email': 'gary.jackson@qlx.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://enterlifeonline.medium.com/',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
